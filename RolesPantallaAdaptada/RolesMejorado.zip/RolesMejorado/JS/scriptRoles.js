function crearRol(boton) {
    let obj={
        url:"../Controller/controllerRol.php?btn_crear="+boton
    }
    $.ajax(obj) // Aquí se cambió $ajax por $.ajax
    .done((resp)=>{
        $(".modal-content").html(resp);
    }).fail(()=>{
        $(".modal-content").html("Oops!, hemos tenido un error al cargar la vista");
    });
}

function editarRol(boton, rol_cod,campo) {
    let obj={
        url:"../Controller/controllerRol.php?btn_editar="+boton+"&cod="+rol_cod+"&campo="+campo
    }
    $.ajax(obj) // Aquí se cambió $ajax por $.ajax
    .done((resp)=>{
        $(".modal-content").html(resp);
    }).fail(()=>{
        $(".modal-content").html("Oops!, hemos tenido un error al cargar la vista");
    });
}

function eliminarRol(boton, rol_cod,campo) {
    let obj={
        url:"../Controller/controllerRol.php?btn_eliminar="+boton+"&cod="+rol_cod+"&campo="+campo
    }
    $.ajax(obj) // Aquí se cambió $ajax por $.ajax
    .done((resp)=>{
        $(".modal-content").html(resp);
    }).fail(()=>{
        $(".modal-content").html("Oops!, hemos tenido un error al cargar la vista");
    });
}