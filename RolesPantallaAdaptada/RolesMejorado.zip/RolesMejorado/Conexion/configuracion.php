<?php
    // Establecemos los parametros de conexion a la base de datos
    /* $server="localhost";
    $username="u339014238_ajstore";
    $password="AndriusJStore2023";
    $database="u339014238_jewelry_store"; */

    $server="localhost";
    $username="root";
    $password="";
    $database="usuarios";
?>